<?php
/**
 * Copyright © Magenest, Inc. All rights reserved.
 */

use \Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::LIBRARY, 'magenest/sagepay-lib', __DIR__);