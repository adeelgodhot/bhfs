# README
Thank you for buying our product.
This extension adheres to [Magenest](https://store.magenest.com/).

## NOTE
This extension supports Sage Payment Europe only. Please refer to our Sage Payment US extension if you want to integrate the extension to Sage Payment US 

## User guide
- If you have trouble installing this extension, please visit: http://confluence.izysync.com/display/DOC/1.+Sage+Pay+Payments+and+Subscriptions+Installation+Guides

- For detailed user guide of this extension, please visit: http://confluence.izysync.com/display/DOC/2.+Sage+Pay+Payments+and+Subscriptions+User+Guides

- Support portal:  http://servicedesk.izysync.com/servicedesk/customer/portal/37

- All the updates of this module are included in CHANGELOG.md file.