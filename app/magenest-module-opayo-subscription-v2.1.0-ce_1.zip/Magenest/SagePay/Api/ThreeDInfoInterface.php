<?php


namespace Magenest\SagePay\Api;


interface ThreeDInfoInterface
{
    /**
     * @return mixed
     */
    public function get3DInfo();
}
